package com.joblog.post.controller;

import com.joblog.common.resolver.LoginUser;
import com.joblog.post.domain.Post;
import com.joblog.post.dto.PostRequest;
import com.joblog.post.dto.PostResponse;
import com.joblog.post.dto.PostUpdateRequest;
import com.joblog.post.service.PostService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/posts")
@RequiredArgsConstructor
public class PostController {
    private final PostService postService;

    @PostMapping
    public ResponseEntity<Long> createPost(@RequestBody @Valid PostRequest request,
                                             @LoginUser String email) {
        Long postId = postService.create(request, email);
        return ResponseEntity.status(HttpStatus.CREATED).body(postId);
    }

    @GetMapping
    public ResponseEntity<Page<PostResponse>> searchPost(
            @RequestParam(required = false) String title,
            @RequestParam(required = false) String authorEmail,
            Pageable pageable) {
        Page<PostResponse> posts = postService.searchPost(title, authorEmail, pageable);
        return ResponseEntity.ok(posts);
    }

    @PatchMapping("/{id}")
    public ResponseEntity<Void> updatePost(@PathVariable Long id,
                                           @RequestBody @Valid PostUpdateRequest request,
                                           @LoginUser String email) {
        postService.update(id, request, email);
        return ResponseEntity.ok().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> updatePost(@PathVariable Long id,
                                           @LoginUser String email) {
        postService.delete(id, email);
        return ResponseEntity.noContent().build();
    }
}
