package com.joblog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JoblogBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(JoblogBackendApplication.class, args);
    }

}
