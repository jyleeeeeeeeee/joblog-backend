package com.joblog.comment.controller;

import com.joblog.comment.dto.CommentRequest;
import com.joblog.comment.service.CommentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/comments")
public class CommentController {
    private final CommentService commentService;

    /**
     * 댓글 등록
     */
    @PostMapping
    public ResponseEntity<Void> create(@RequestBody @Valid CommentRequest request) {
        commentService.create(request);
        return ResponseEntity.ok().build();
    }

    /**
     * 댓글 수정
     */
    @PatchMapping("/{commentId}")
    public ResponseEntity<Void> update(@PathVariable Long commentId,
                                       @RequestBody @Valid CommentRequest request) {
        commentService.update(commentId, request);
        return ResponseEntity.ok().build();
    }

    /**
     * 댓글 삭제 (soft delete)
     */
    @DeleteMapping("/{commentId}")
    public ResponseEntity<Void> delete(@PathVariable Long commentId) {
        commentService.delete(commentId);
        return ResponseEntity.ok().build();
    }

}
