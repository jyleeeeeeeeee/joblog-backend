package com.joblog.comment.service;

import com.joblog.comment.dto.CommentRequest;
import com.joblog.comment.dto.CommentResponse;

import java.util.List;

public interface CommentService {
    void create(CommentRequest request);

    void update(Long commentId, CommentRequest request);

    void delete(Long commentId);

    List<CommentResponse> getCommentsByPost(Long postId);
}
